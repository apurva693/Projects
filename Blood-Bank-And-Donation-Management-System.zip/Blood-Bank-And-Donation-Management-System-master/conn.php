<?php
$conn=mysqli_connect("localhost","sahil1","123","blood_donation") or die("Connection error");
?>
